public class Q1_Float {
	public static void main(String[] args){
		int f1 = 9527.123;
		float f2 = 9527.123;
			System.out.println("f1 ="+f1):
			System.out.println("f2 ="+f2);
	}
}
