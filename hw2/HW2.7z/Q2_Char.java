public class Q1_Char {
	public static void main(String[] args){
		char ch1,ch2,ch3,ch4,ch5,ch6;
		ch1 = ''';
		ch2 = '/"';
		ch3 = '/n';
		ch4 = '\';
		ch5 = '?';
		ch6 = ':';
		System.out.println("char1 =" +ch1+ "\nchar2 =" +ch2+ "\nchar3 =" +ch3+ "\nchar4 =" +ch4+ "\nchar5 =" +ch5 + "\nchar6 =" +ch6);
	}
}
