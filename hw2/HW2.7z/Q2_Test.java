public class q2_test {
	public static void main(String[] args){
		int 1st = 4;
		system.Out.Println("HelloWorld")
	}
}
