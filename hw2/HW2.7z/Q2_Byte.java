public class Q1_Byte{
	public static void main(String[] args){
		byte b = 012 + 0xff0a;
		byte class = 1;
	}
}
